"""
Checks how well the cheap local-SLM quality judge (quality_local_* columns) agrees with the
Claude judge (quality_* columns) on rows where BOTH exist -- the validation step that makes
"use a local model as a cheap first pass" a defensible methodology choice rather than an
unverified assumption. Report this number in your dissertation either way: strong agreement
justifies leaning on the local pass for triage; weak agreement is itself a real finding worth
stating (and a reason to rely on Claude for anything you actually report).

Run from the project root:
    python scripts/compare_quality_judges.py
    python scripts/compare_quality_judges.py --history results/logs/results_history.csv
"""
import argparse
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.quality import QUALITY_DIMS


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--history", default="results/logs/results_history.csv")
    args = ap.parse_args()

    if not os.path.exists(args.history):
        raise FileNotFoundError(f"{args.history} not found")

    df = pd.read_csv(args.history)
    dims_and_overall = QUALITY_DIMS + ["overall"]
    needed = {f"quality_{d}" for d in dims_and_overall} | {f"quality_local_{d}" for d in dims_and_overall}
    missing = needed - set(df.columns)
    if missing:
        raise ValueError(
            f"{args.history} is missing {sorted(missing)} -- you need rows scored by BOTH judges "
            f"(--score-quality and --score-quality-local, or the equivalent backfill) before "
            f"this comparison means anything."
        )

    both = df.dropna(subset=["quality_overall", "quality_local_overall"])
    if both.empty:
        print("No rows have scores from both judges yet -- nothing to compare.")
        return
    if len(both) < 10:
        print(f"Only {len(both)} rows have both judges' scores -- treat this comparison as very preliminary; "
              f"score more rows with both judges before trusting the agreement number below.")

    print(f"Comparing {len(both)} rows scored by both judges.\n")

    print("Mean score by judge, per dimension:")
    claude_means = both[[f"quality_{d}" for d in dims_and_overall]].mean()
    local_means = both[[f"quality_local_{d}" for d in dims_and_overall]].mean()
    comparison = pd.DataFrame({"claude": claude_means.values, "local": local_means.values}, index=dims_and_overall)
    comparison["gap"] = comparison["claude"] - comparison["local"]
    print(comparison.round(2).to_string())

    diff = both["quality_overall"] - both["quality_local_overall"]
    print(f"\nOverall score -- mean absolute difference: {diff.abs().mean():.2f} (on a 1-5 scale)")
    print(f"Overall score -- mean signed difference (Claude minus local): {diff.mean():+.2f}")
    if diff.mean() > 0.3:
        print("  (local judge is systematically more lenient than Claude)")
    elif diff.mean() < -0.3:
        print("  (local judge is systematically harsher than Claude)")

    corr = both["quality_overall"].corr(both["quality_local_overall"])
    print(f"\nPearson correlation between judges (overall score): {corr:.3f}")
    if corr >= 0.7:
        print("  Strong agreement -- reasonable to treat the local judge as a useful triage signal.")
    elif corr >= 0.4:
        print("  Moderate agreement -- usable as a rough filter, but don't over-trust individual local scores.")
    else:
        print("  Weak agreement -- the local judge does not reliably track Claude's scoring here. This is a")
        print("  real, citable finding for your dissertation (consistent with the judge-capability literature),")
        print("  not a failure of the experiment -- just don't lean on the local judge beyond a coarse filter.")


if __name__ == "__main__":
    main()
