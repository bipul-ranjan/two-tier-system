"""
Main pipeline: pick random rows from the synthetic Bitext-format CSVs
(data/synthetic/synthetic_bitext_*.csv), run each through the two-tier
cascade, and log every decision for later evaluation.

- Business unit comes from the row's category (CARD/TRANSFER/ATM/FEES/
  PAYMENT_EXCEPTION -> payments; ACCOUNT/LOAN/PASSWORD/CONTACT/FIND/
  RETAIL_EXCEPTION -> retail_bank), so each query goes to the right
  assistant instead of an arbitrary split.
- Routing is done by the LEARNED ROUTER (src/learned_router.py) by default: once Tier 1 has
  answered, the router predicts how good that answer is from the question, the answer, Tier 1's
  confidence and the business unit, and the question is escalated when the prediction falls
  below a cut-point. Train it first with scripts/train_text_router.py. If the model file is
  missing the run stops with a clear message; it never silently falls back to another rule.
  Flow:  query -> Tier 1 -> response -> router -> escalate? -> (no) send Tier 1's answer
                                                           -> (yes) cache, then Claude -> send
  Pass --threshold-router to use the older rule instead (below), e.g. to compare the two
  routers on the same sample.
- The older threshold rule: a confidence pass mark per business unit (and per normal/exception
  scenario within it) via the THRESHOLDS dict below, since different Tier 1 models can have very
  different confidence distributions -- a smaller fine-tuned model naturally produces less
  confident answers even when its content is fine.
- Both confidence methods (avg and min) are logged for every query. The threshold rule routes
  on confidence_score (currently = the avg method) via router.route(); the learned router uses
  the avg confidence as one of its inputs.
- Every row logs which router decided (router), the predicted quality (router_predicted_quality)
  and the cut-point (router_cutoff). Under the threshold rule threshold_used is filled and the
  predicted quality and cut-point are blank; under the learned router it is the other way round.
- Latency is logged three ways per query, so it can be evaluated properly:
    request_start_time / response_end_time  wall-clock timestamps
    tier1_latency_ms, tier2_latency_ms      time spent in each tier
    total_latency_ms                        end-to-end (tier 1 + routing + tier 2)
  plus tier1_load_ms (Ollama's model-load time inside the Tier 1 call --
  large on a cold start, ~0 when the model is already in memory) and
  tier1_output_tokens (answer length, which drives generation time).
- Models are preloaded before the first query, kept loaded for the whole run
  (KEEP_ALIVE), and unloaded when the run ends -- including on an error or
  Ctrl+C -- so model-load time never lands inside a query's latency.
- Every run gets a run_id, run-<dd-mmm-yy>-<hh:mm AM/PM> (e.g. run-28-Sep-26-06:29 PM),
  as the first column of every log. results_log_*.csv hold the LATEST run only (which is
  what evaluate.py reads); every run is also appended to results/logs/results_history.csv,
  so runs -- e.g. before and after retraining -- can be compared.

Run from the project root, inside the venv, with Ollama running and ANTHROPIC_API_KEY set:

    python -m src.pipeline                   # 100 random questions (N_SAMPLES), every default on
    python -m src.pipeline 50                # 50 random questions

Options, all optional and in any order after the number of questions:
    --threshold-router         route with the older confidence pass marks (THRESHOLDS below) instead of the
                               learned router. Use it to compare the two routers on the same questions
    --nocache                  skip the semantic cache, so every escalation calls Claude
    --no-redact                turn the personal-data filter off (it is on by default); only for reproducing older runs
    --noquality                skip the Claude quality marking after the run (quality columns stay blank;
                               fill them later with scripts/backfill_quality_scores.py)
    --score-quality-local M    also mark answers with the local Ollama model M, a cheap first pass written to
                               separate quality_local_* columns (not the numbers to report)
Unknown options are rejected with the list of valid ones. Defaults, with nothing after the number: learned router
ON, semantic cache ON, Claude quality marking ON.

What a run needs and does
    Needs      Ollama running with the models named in src/config.py; ANTHROPIC_API_KEY for Claude (escalations
               and quality marking); models/router/text_probe_router.joblib for the learned router (train it with
               scripts/train_text_router.py); data/synthetic/synthetic_bitext_*.csv, the question pool.
    Writes     results/logs/results_log_combined.csv (this run only), one results_log_<unit>.csv per business
               unit, and results/logs/results_history.csv (every run, appended; locked for the whole run so nothing
               else can open it). See results/logs/README.md for every column.
    Prints     one block per question, then a summary of decisions, median latency and the router's escalation share.
    Fails      before anything is loaded if the router model is missing or was trained under another scikit-learn
               version, and the history file is locked from the moment the run starts. A row that fails is
               skipped with a warning and every other row is still saved. Ctrl+C during quality marking still saves.

Reproducible run: set SEED (below) to a number and the same questions are drawn every time. With SEED = None
each run draws different ones, so two runs differ partly because their questions do.
"""
import glob
import os
import sys
import time
from datetime import datetime
import pandas as pd
import requests

from .config import OLLAMA_URL, get_model_for_unit
from .tier1 import ask_tier1
from .router import route
from .learned_router import TextProbeRouter, RouterNotTrainedError
from .tier2_escalate import ask_tier2, estimate_cost, client as anthropic_client
from .quality import judge_answer_quality, judge_answer_quality_local, QUALITY_DIMS
from .semantic_cache import SemanticCacheIndex, try_semantic_cache
from .privacy import redact, merge_findings, RedactionResult, FILTER_VERSION, ANSWER_TYPES

# Whole-file exclusive locking so results_history.csv cannot be opened elsewhere
# (Excel, a text editor) for the whole duration of a run -- not just checked once
# at the start. msvcrt on Windows, flock on Mac/Linux.
if sys.platform == "win32":
    import msvcrt
else:
    import fcntl

SYNTHETIC_DIR = "data/synthetic"
LOGS_DIR = "results/logs"

N_SAMPLES = 100
SEED = None  # None = different random rows every run; set an int to reproduce a run
REDACT_PII = True  # the personal-data filter (src/privacy.py); main() sets it False for --no-redact

# Escalate anything scoring below its threshold. Threshold is set per business unit,
# and can be set separately for normal vs. exception rows within a unit -- edit the
# values below to whatever your data supports. A unit not listed here, or a run whose
# rows have no business_unit match, falls back to DEFAULT_THRESHOLD.
THRESHOLDS = {
    "payments": {"normal": 0.71, "exception": 0.71},
    # 0.55 is a suggested starting point, not a measured optimum: it sits just above
    # retail_bank's own mean/median confidence (0.529 / 0.527 in the latest run), the
    # same relationship 0.7 already has to payments' mean (0.700). Re-tune from the
    # Overview page once you have more runs at this setting.
    "retail_bank": {"normal": 0.6, "exception": 0.6},
}
DEFAULT_THRESHOLD = 0.7


def get_threshold(business_unit: str, is_exception: bool) -> float:
    """The confidence pass mark for a business unit and scenario (normal or exception), falling back to
    DEFAULT_THRESHOLD for a unit that is not listed. Used by the older threshold router only.
    """
    scenario = "exception" if is_exception else "normal"
    return THRESHOLDS.get(business_unit, {}).get(scenario, DEFAULT_THRESHOLD)

# How long Ollama keeps a model loaded after each request during a run. Finite on
# purpose: if the script is killed hard (so it can't unload), the models still free
# themselves after this long.
KEEP_ALIVE = "30m"

HISTORY_PATH = f"{LOGS_DIR}/results_history.csv"

PAYMENTS_CATEGORIES = {"CARD", "TRANSFER", "ATM", "FEES", "PAYMENT_EXCEPTION"}
RETAIL_CATEGORIES = {"ACCOUNT", "LOAN", "PASSWORD", "CONTACT", "FIND", "RETAIL_EXCEPTION"}
EXCEPTION_CATEGORIES = {"PAYMENT_EXCEPTION", "RETAIL_EXCEPTION"}


def unit_for_category(category: str) -> str:
    """Map a data category (CARD, ACCOUNT ...) to its business unit. An unknown category raises, so
    nothing is silently routed to the wrong unit.
    """
    if category in PAYMENTS_CATEGORIES:
        return "payments"
    if category in RETAIL_CATEGORIES:
        return "retail_bank"
    raise ValueError(f"Unknown category '{category}' -- add it to PAYMENTS_CATEGORIES or RETAIL_CATEGORIES")


def load_random_sample(n: int = N_SAMPLES, seed=SEED) -> pd.DataFrame:
    """Pool every synthetic CSV and draw n random rows from the whole pool."""
    files = sorted(glob.glob(f"{SYNTHETIC_DIR}/synthetic_bitext_*.csv"))
    if not files:
        raise FileNotFoundError(
            f"No files matching {SYNTHETIC_DIR}/synthetic_bitext_*.csv -- "
            f"run scripts/generate_synthetic_bitext.py (or unzip the CSVs there) first."
        )
    pool = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
    sample = pool.sample(n=min(n, len(pool)), random_state=seed).reset_index(drop=True)
    sample["business_unit"] = sample["category"].map(unit_for_category)
    sample["is_exception"] = sample["category"].isin(EXCEPTION_CATEGORIES)
    return sample


def make_run_id(existing_ids=(), now=None) -> str:
    """run-<dd-mmm-yy>-<hh:mm AM/PM>. If that id is already taken (two runs inside the
    same minute), a -2, -3 ... suffix keeps ids unique."""
    base = (now or datetime.now()).strftime("run-%d-%b-%y-%I:%M %p")
    if base not in existing_ids:
        return base
    n = 2
    while f"{base}-{n}" in existing_ids:
        n += 1
    return f"{base}-{n}"


def existing_run_ids() -> set:
    """The run ids already in results_history.csv, so that a new run id can never collide with an old
    one.
    """
    if not os.path.exists(HISTORY_PATH):
        return set()
    try:
        return set(pd.read_csv(HISTORY_PATH, usecols=["run_id"])["run_id"].dropna())
    except ValueError:
        return set()


def guard_legacy_log() -> None:
    """Refuse to overwrite an older results log that has no run_id, so its data is not lost."""
    combined = f"{LOGS_DIR}/results_log_combined.csv"
    if os.path.exists(combined) and "run_id" not in pd.read_csv(combined, nrows=0).columns:
        raise RuntimeError(
            f"{combined} has no run_id column and this run would overwrite it. "
            f"Run `python scripts/backfill_run_id.py` first, so the existing results are kept."
        )


def guard_writable(paths) -> None:
    """Fail fast, before spending any time or Claude API cost, if a log file is open
    elsewhere (e.g. Excel on Windows) and would refuse to be written to at the end
    of the run. Only checks files that already exist -- a new file is always writable."""
    for path in paths:
        if not os.path.exists(path):
            continue
        try:
            with open(path, "a"):
                pass
        except PermissionError as e:
            raise RuntimeError(
                f"Cannot write to {path} -- it looks like it's open in another program "
                f"(Excel, a text editor, etc.). Close it there first, then re-run. ({e})"
            ) from e


# Sentinel byte-count used for msvcrt.locking(). Windows lets you lock a region larger
# than the file's current size (it just has to be consistent between lock and unlock),
# so one large fixed value safely covers the file at any size it might grow to.
_WIN_LOCK_BYTES = 0x7FFFFFFF - 1


class HistoryLock:
    """Holds an exclusive OS-level lock on results_history.csv for an entire pipeline
    run, so nothing else (Excel, a text editor, a second run of the pipeline) can open
    it from the moment the run starts until it finishes and the file is updated --
    not just at the final save step. Use as a context manager:

        with HistoryLock(HISTORY_PATH) as lock:
            ...run the whole pipeline...
            lock.write(final_history_dataframe)

    The lock is always released on the way out, including if the run raises partway
    through, so a crash never leaves the file stuck locked.
    """

    def __init__(self, path: str):
        self.path = path
        self.file = None

    def __enter__(self):
        if not os.path.exists(self.path):
            open(self.path, "a", encoding="utf-8").close()  # create it so it can be reopened in r+ mode
        try:
            # encoding="utf-8" matches pandas' own default for read_csv/to_csv when given a
            # path directly. Without it, Python falls back to the OS's local codepage (cp1252
            # on Windows), which cannot decode the UTF-8 bytes pandas itself writes -- that
            # mismatch, not the file's actual content, is what caused the UnicodeDecodeError.
            self.file = open(self.path, "r+", newline="", encoding="utf-8")
        except PermissionError as e:
            raise RuntimeError(
                f"Cannot open {self.path} -- it looks like it's open in another program "
                f"(Excel, a text editor, etc.). Close it there first, then re-run. ({e})"
            ) from e
        try:
            self._lock()
        except OSError as e:
            self.file.close()
            self.file = None
            raise RuntimeError(
                f"{self.path} is locked by another program (Excel, a text editor, or "
                f"another run of the pipeline). Close it there first, then re-run. ({e})"
            ) from e
        return self

    def _lock(self) -> None:
        """Take an exclusive lock on the open file (msvcrt on Windows, flock elsewhere). Fails at once
        if another program holds it.
        """
        self.file.seek(0)
        if sys.platform == "win32":
            msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, _WIN_LOCK_BYTES)
        else:
            fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)

    def _unlock(self) -> None:
        """Release the lock taken by _lock."""
        self.file.seek(0)
        if sys.platform == "win32":
            msvcrt.locking(self.file.fileno(), msvcrt.LK_UNLCK, _WIN_LOCK_BYTES)
        else:
            fcntl.flock(self.file.fileno(), fcntl.LOCK_UN)

    def read(self) -> pd.DataFrame:
        """Read the locked file's current contents through the same open handle."""
        self.file.seek(0)
        try:
            return pd.read_csv(self.file)
        except pd.errors.EmptyDataError:
            return pd.DataFrame()

    def write(self, df: pd.DataFrame) -> None:
        """Overwrite the locked file's contents with df, through the same open handle --
        never opens a second handle to the path, so it can't collide with the lock."""
        self.file.seek(0)
        self.file.truncate()
        df.to_csv(self.file, index=False)
        self.file.flush()
        os.fsync(self.file.fileno())

    def __exit__(self, exc_type, exc, tb):
        if self.file is not None:
            try:
                self._unlock()
            finally:
                self.file.close()
                self.file = None
        return False


def load_models(models: list) -> None:
    """Load each model into memory now (a generate request with no prompt just loads it)."""
    for m in models:
        t = time.perf_counter()
        try:
            r = requests.post(OLLAMA_URL, json={"model": m, "keep_alive": KEEP_ALIVE}, timeout=300)
            r.raise_for_status()
        except requests.RequestException as e:
            raise RuntimeError(
                f"Could not load model '{m}'. Is Ollama running, and has `ollama create` been run for it? ({e})"
            ) from e
        print(f"Loaded {m} in {time.perf_counter() - t:.1f} s")


def warn_if_not_resident(models: list) -> None:
    """Ollama unloads an idle model if a new one does not fit alongside it. Check that
    every model is actually still in memory, and warn loudly if not."""
    try:
        base = OLLAMA_URL.rsplit("/api/", 1)[0]
        running = requests.get(f"{base}/api/ps", timeout=10).json().get("models", [])
    except (requests.RequestException, ValueError, AttributeError):
        return
    norm = lambda n: n if ":" in n else n + ":latest"
    resident = {norm(m.get("name", "")) for m in running}
    missing = [m for m in models if norm(m) not in resident]
    if missing:
        print(f"WARNING: {missing} not resident after preloading -- the models do not fit in memory "
              f"together, so Ollama will swap them and tier1_load_ms will stay high.")


def unload_models(models: list) -> None:
    """Unload each model (keep_alive 0). Never raises -- this runs in a finally block."""
    for m in models:
        try:
            requests.post(OLLAMA_URL, json={"model": m, "keep_alive": 0}, timeout=60).raise_for_status()
            print(f"Unloaded {m}")
        except requests.RequestException as e:
            print(f"Warning: could not unload {m}: {e}")


def _outbound(text, answer: bool = False, known=None) -> RedactionResult:
    """The copy of a piece of text that may leave the organisation or be stored in the log: redacted when
    the personal-data filter is on (the default), unchanged under --no-redact. A question is filtered in full.
    An answer (answer=True) is filtered for customer-identifier types only, plus any value from the question
    (known) that it repeats back, because phone numbers and addresses in answers are normally public contacts."""
    if not REDACT_PII:
        return RedactionResult(text=text if isinstance(text, str) else "")
    return redact(text, only=ANSWER_TYPES, known=known) if answer else redact(text)


def process_query(query: str, business_unit: str, category: str, intent: str, is_exception: bool, run_id: str,
                   cache_index: SemanticCacheIndex = None, router: TextProbeRouter = None) -> dict:
    """Run one question through the whole cascade and return its log row. Tier 1 answers and reports
    its confidence; the router (the learned router, or the threshold rule when router is None)
    decides LOCAL or ESCALATE; an escalated question is looked up in the semantic cache (decision
    CACHE on a hit) and otherwise sent to Claude (decision ESCALATE). Timings for every step are
    recorded, and the row is printed as it is built.
    """
    threshold = get_threshold(business_unit, is_exception)

    start_dt = datetime.now()
    t_query_start = time.perf_counter()

    t1_result = ask_tier1(query, business_unit=business_unit, keep_alive=KEEP_ALIVE)
    tier1_latency_ms = (time.perf_counter() - t_query_start) * 1000

    # Privacy boundary. Tier 1 runs on the organisation's own servers, so it saw the original question. Anything
    # that leaves that boundary (Claude, the cache lookup, the examiner) or is stored (the log) uses the
    # redacted copy, and so does the router, so it reads the same text it was trained on.
    q_red = _outbound(query)
    a_red = _outbound(t1_result["answer"], answer=True, known=q_red.originals)
    safe_query, safe_t1_answer = q_red.text, a_red.text
    pii_findings = merge_findings(q_red, a_red)

    if router is not None:
        # The learned router reads the question, Tier 1's answer, its confidence and the unit,
        # predicts the answer's quality, and escalates below its cut-point.
        predicted_quality = router.predict_one(safe_query, safe_t1_answer, t1_result["confidence_score_avg"], business_unit)
        decision = router.decide(predicted_quality)
        router_name, router_cutoff, threshold_logged = router.version, router.cutoff, None
    else:
        decision = route(t1_result["confidence_score"], threshold)
        predicted_quality, router_name, router_cutoff, threshold_logged = None, "threshold", None, threshold

    print(f"Start Time     : {start_dt.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Business Unit  : {t1_result['business_unit']} ({t1_result['assistant_name']})")
    print(f"Scenario       : {category} / {intent}{'  [EXCEPTION]' if is_exception else ''}")
    print(f"Query          : {safe_query}")
    print(f"Tier 1 Answer  : {safe_t1_answer[:100]}{'...' if len(safe_t1_answer) > 100 else ''}")
    if pii_findings:
        print(f"Personal data  : {sum(pii_findings.values())} replaced ({', '.join(sorted(pii_findings))}) before anything leaves or is logged")
    print(f"Confidence AVG : {t1_result['confidence_score_avg']:.4f}")
    print(f"Confidence MIN : {t1_result['confidence_score_min']:.4f}")
    if router is not None:
        print(f"Router         : {router_name} | predicted quality {predicted_quality:.2f} (cut-point {router_cutoff:.2f})")
    else:
        print(f"Threshold      : {threshold}")
    print(f"Decision       : {decision}")

    row = {
        "run_id": run_id,
        "request_start_time": start_dt.isoformat(timespec="milliseconds"),
        "response_end_time": None,
        "business_unit": business_unit,
        "assistant_name": t1_result["assistant_name"],
        "tier1_model": t1_result["model"],
        "category": category,
        "intent": intent,
        "is_exception": is_exception,
        "query": safe_query,
        "tier1_answer": safe_t1_answer,
        "tier1_confidence_avg": t1_result["confidence_score_avg"],
        "tier1_confidence_min": t1_result["confidence_score_min"],
        "threshold_used": threshold_logged,
        "router": router_name,
        "router_predicted_quality": round(predicted_quality, 4) if predicted_quality is not None else None,
        "router_cutoff": round(router_cutoff, 4) if router_cutoff is not None else None,
        "decision": decision,
        "tier1_latency_ms": round(tier1_latency_ms, 1),
        "tier2_latency_ms": None,
        "total_latency_ms": None,
        "tier1_load_ms": t1_result.get("ollama_load_ms"),
        "tier1_output_tokens": t1_result.get("ollama_output_tokens"),
        "tier2_input_tokens": None,
        "tier2_output_tokens": None,
        "tier2_confidence": None,
        "tier2_prompt_version": None,
        "estimated_cost_usd": 0.0,
        "final_answer": safe_t1_answer,
        "cache_hit": False,
        "cache_similarity": None,
        "cache_path": None,  # "direct" when cache_hit is True (always "direct" now -- the gray-zone
                             # verification path was removed; see src/semantic_cache.py)
        "cache_matched_query": None,
        "pii_filter": FILTER_VERSION if REDACT_PII else "off",
        "pii_count": None,
        "pii_types": None,
    }

    tier2_latency_ms = None
    if decision == "ESCALATE":
        cache_result = None
        if cache_index is not None:
            try:
                cache_result = try_semantic_cache(cache_index, safe_query, category=category, intent=intent)
            except Exception as e:
                # The cache is an optimisation, not the pipeline's job: if a lookup fails for
                # any reason, treat it as a miss and escalate normally rather than losing the row.
                print(f"    WARNING: cache lookup failed ({type(e).__name__}: {e}) -- treating as a miss")
        if cache_result is not None:
            # Served from the semantic cache -- no Tier 2 call, no cost, and no extra latency
            # beyond the cache lookup itself. The router said ESCALATE (Tier 1 wasn't confident
            # enough to answer alone), but nothing was actually escalated, so the logged
            # decision is CACHE: every row is exactly one of LOCAL (Tier 1 answered), CACHE
            # (a past Claude answer was re-served) or ESCALATE (Claude was called).
            row["decision"] = "CACHE"
            print(f"Cache hit      : similarity {cache_result['similarity']:.4f} -> decision CACHE (no Claude call)")
            row["cache_hit"] = True
            row["cache_similarity"] = round(cache_result["similarity"], 4)
            row["cache_path"] = cache_result["path"]
            row["cache_matched_query"] = cache_result["matched_query"]
            cached_red = _outbound(cache_result["answer"], answer=True, known=q_red.originals)
            row["final_answer"] = cached_red.text
            pii_findings = merge_findings(RedactionResult("", pii_findings), cached_red)
        else:
            t2_start = time.perf_counter()
            t2_result = ask_tier2(safe_query, business_unit=business_unit)
            tier2_latency_ms = (time.perf_counter() - t2_start) * 1000
            row["tier2_latency_ms"] = round(tier2_latency_ms, 1)
            row["tier2_input_tokens"] = t2_result["input_tokens"]
            row["tier2_output_tokens"] = t2_result["output_tokens"]
            row["tier2_confidence"] = t2_result["confidence"]
            row["tier2_prompt_version"] = t2_result["prompt_version"]
            row["estimated_cost_usd"] = estimate_cost(t2_result["input_tokens"], t2_result["output_tokens"])
            t2_red = _outbound(t2_result["answer"], answer=True, known=q_red.originals)
            row["final_answer"] = t2_red.text
            pii_findings = merge_findings(RedactionResult("", pii_findings), t2_red)

    total_latency_ms = (time.perf_counter() - t_query_start) * 1000
    row["total_latency_ms"] = round(total_latency_ms, 1)
    row["pii_count"] = sum(pii_findings.values())
    row["pii_types"] = ",".join(sorted(pii_findings))
    row["response_end_time"] = datetime.now().isoformat(timespec="milliseconds")

    tier2_text = f"{tier2_latency_ms:.0f} ms" if tier2_latency_ms is not None else "-"
    tier2_conf_text = f" (Claude confidence {row['tier2_confidence']:.2f})" if row["tier2_confidence"] is not None else ""
    load_ms = row["tier1_load_ms"]
    load_text = f" (model load {load_ms:.0f} ms)" if load_ms else ""
    print(f"Latency        : Tier1 {tier1_latency_ms:.0f} ms{load_text} | Tier2 {tier2_text}{tier2_conf_text} | Total {total_latency_ms:.0f} ms")
    print("-" * 60)
    return row


def score_quality_pass(rows: list) -> None:
    """Score every row's Tier 1 answer for quality (correctness/completeness/tone/safety/
    clarity, 1-5 each, via Claude-as-judge -- see src/quality.py), in place, adding
    quality_<dimension>, quality_overall and quality_note keys to each row dict. Runs AFTER
    all Tier 1/Tier 2 processing is done, so it never affects routing or latency numbers --
    it's a separate, offline measurement of whether the answers are actually good, not just
    confidently produced. This is one extra Claude API call per row: for a large sample this
    adds real time and cost on top of the pipeline run itself, which is why it can be skipped
    with --noquality.
    """
    print(f"\nScoring answer quality for {len(rows)} rows (Claude-as-judge, {QUALITY_DIMS})...")
    for i, row in enumerate(rows, 1):
        # final_answer, not tier1_answer: for an escalated row, tier1_answer is the discarded
        # low-confidence draft, and final_answer is what Tier 2 actually produced and the
        # customer actually received. Scoring tier1_answer for an escalated row would measure
        # the wrong text entirely.
        result = judge_answer_quality(anthropic_client, row["query"], row["final_answer"])
        if result:
            for dim in QUALITY_DIMS:
                row[f"quality_{dim}"] = result[dim]
            row["quality_overall"] = round(sum(result[d] for d in QUALITY_DIMS) / len(QUALITY_DIMS), 2)
            row["quality_note"] = result["note"]
        else:
            for dim in QUALITY_DIMS:
                row[f"quality_{dim}"] = None
            row["quality_overall"] = None
            row["quality_note"] = None
        if i % 10 == 0 or i == len(rows):
            print(f"  {i}/{len(rows)} scored")


def score_draft_pass(rows: list) -> None:
    """Fill quality_draft_* on EVERY row, so no quality cell is left blank. This is what each
    row's Tier 1 answer was worth:
      - LOCAL rows: Tier 1's answer IS the final answer, so the draft scores are simply a copy
        of the final-answer scores -- no extra judge call.
      - ESCALATE and CACHE rows (fresh Claude answer, or a cached one): Tier 1's answer was discarded, so
        tier1_answer gets its own judge call -- a same-query comparison against the quality of
        the answer the customer actually received (quality_*).
    Runs after score_quality_pass, since LOCAL rows copy from its output.
    """
    escalated = [r for r in rows if r["decision"] in ("ESCALATE", "CACHE")]   # Tier 1's draft was discarded on both
    print(f"\nFilling Tier 1 quality on every row: copying final-answer scores onto {len(rows) - len(escalated)} local rows, "
          f"scoring the discarded Tier 1 draft on {len(escalated)} escalated rows...")
    for row in rows:
        if row["decision"] == "LOCAL":
            for dim in QUALITY_DIMS:
                row[f"quality_draft_{dim}"] = row.get(f"quality_{dim}")
            row["quality_draft_overall"] = row.get("quality_overall")
            row["quality_draft_note"] = row.get("quality_note")
    for i, row in enumerate(escalated, 1):
        result = judge_answer_quality(anthropic_client, row["query"], row["tier1_answer"])
        if result:
            for dim in QUALITY_DIMS:
                row[f"quality_draft_{dim}"] = result[dim]
            row["quality_draft_overall"] = round(sum(result[d] for d in QUALITY_DIMS) / len(QUALITY_DIMS), 2)
            row["quality_draft_note"] = result["note"]
        else:
            for dim in QUALITY_DIMS:
                row[f"quality_draft_{dim}"] = None
            row["quality_draft_overall"] = None
            row["quality_draft_note"] = None
        if i % 10 == 0 or i == len(escalated):
            print(f"  {i}/{len(escalated)} drafts scored")


def score_quality_pass_local(rows: list, judge_model: str) -> None:
    """Cheap, broad first-pass quality scoring via a local Ollama model instead of Claude --
    fast and free enough to run over every row without the cost concern that makes the
    Claude pass opt-in. Writes quality_local_<dimension> columns, kept separate from
    quality_<dimension> (the Claude-judged columns) so it's never mistaken for the numbers
    you'd actually report. Treat this as a triage signal, not a citable result on its own --
    run scripts/backfill_quality_scores.py with and without --judge-local and compare the two
    sets of columns to check how well it agrees with Claude before
    leaning on it for anything beyond that.
    """
    print(f"\nScoring answer quality locally via {judge_model} for {len(rows)} rows (cheap first pass, not for reporting)...")
    for i, row in enumerate(rows, 1):
        result = judge_answer_quality_local(judge_model, row["query"], row["final_answer"])  # see comment above
        if result:
            for dim in QUALITY_DIMS:
                row[f"quality_local_{dim}"] = result[dim]
            row["quality_local_overall"] = round(sum(result[d] for d in QUALITY_DIMS) / len(QUALITY_DIMS), 2)
            row["quality_local_note"] = result["note"]
        else:
            for dim in QUALITY_DIMS:
                row[f"quality_local_{dim}"] = None
            row["quality_local_overall"] = None
            row["quality_local_note"] = None
        if i % 25 == 0 or i == len(rows):
            print(f"  {i}/{len(rows)} scored")


def run_pipeline(sample: pd.DataFrame, log_path: str = None, score_quality: bool = False, score_quality_local: str = None,
                  use_semantic_cache: bool = False, use_learned_router: bool = False) -> pd.DataFrame:
    """Run every sampled row through the cascade. Writes one combined log
    (read by evaluate.py) plus one log per business unit.

    use_semantic_cache: opt-in (default off) since, unlike score_quality/score_quality_local,
    this changes live ROUTING behaviour, not just logging -- an escalated query may now be
    served from a cached prior Claude answer instead of making a fresh Tier 2 call. Builds
    the cache index once, from results_history.csv as it stands at the start of this run (so
    cache entries only ever come from genuinely earlier runs' Tier 2 answers, never from rows
    being written during this same run).

    use_learned_router: route with the trained text router instead of the confidence threshold.
    The command line turns this on by default. The model is loaded first of all, so a missing or
    unusable model file stops the run immediately with a clear message, before any model is
    loaded and before anything is locked.
    """
    router = None
    if use_learned_router:
        try:
            router = TextProbeRouter.load()
        except RouterNotTrainedError as e:
            raise SystemExit(f"\n{e}")
        print(f"Router: learned ({router.version}). Escalates answers predicted to score below {router.cutoff:.2f}.")
    if log_path is None:
        log_path = f"{LOGS_DIR}/results_log_combined.csv"
    os.makedirs(LOGS_DIR, exist_ok=True)
    guard_legacy_log()
    unit_log_paths = [f"{LOGS_DIR}/results_log_{u}.csv" for u in sample["business_unit"].unique()]
    guard_writable([log_path, *unit_log_paths])
    run_id = make_run_id(existing_run_ids())
    print(f"Run ID: {run_id}")

    models = sorted({get_model_for_unit(u) for u in sample["business_unit"].unique()})

    # results_history.csv is locked for the whole run, from here until the run finishes
    # and the file is updated -- not just checked once at the start. Nothing else (Excel,
    # a text editor, a second run of the pipeline) can open it in the meantime.
    with HistoryLock(HISTORY_PATH) as lock:
        print(f"Locked {HISTORY_PATH} -- it can't be opened elsewhere until this run finishes.")
        cache_index = None
        if use_semantic_cache:
            print("Building semantic cache index from existing Tier 2 answers...")
            try:
                cache_index = SemanticCacheIndex()
                cache_index.build(lock.read())
                print(f"  {len(cache_index.queries)} cached Tier 2 answers available.")
            except Exception as e:
                # The cache is on by default, so a missing optional dependency (e.g.
                # sentence-transformers not installed) or a failed model download must not take
                # down the whole run -- but it must not be silent either, or a 0% hit rate would
                # look like "no matches" when the cache never actually ran.
                cache_index = None
                print(f"  WARNING: semantic cache unavailable ({type(e).__name__}: {e}).")
                print("  Continuing this run WITHOUT the cache -- every escalation will call Claude.")
                print("  To fix: pip install sentence-transformers   (or pass --nocache to silence this)")
        try:
            print("Preloading models...")
            load_models(models)
            warn_if_not_resident(models)
            print("-" * 60)
            # One row's irrecoverable failure (e.g. Ollama hanging well past its retries in
            # tier1.py) no longer takes the whole batch down -- it's logged and skipped, and
            # every other row still completes and gets saved. Before this, a single bad row
            # late in a multi-hundred-row run meant losing every row that had already
            # succeeded, since nothing is written to disk until the whole loop finishes.
            rows = []
            failed = []
            for r in sample.itertuples(index=False):
                try:
                    rows.append(process_query(r.instruction, r.business_unit, r.category, r.intent, bool(r.is_exception), run_id,
                                               cache_index=cache_index, router=router))
                except Exception as e:
                    failed.append({"query": r.instruction, "business_unit": r.business_unit, "error": str(e)})
                    print(f"  WARNING: row failed and will be skipped ({type(e).__name__}: {e})")
            if failed:
                print(f"\n{len(failed)} of {len(sample)} rows failed and were skipped (see warnings above). "
                      f"The other {len(rows)} rows completed normally and will still be saved.")
        finally:
            print("Unloading models...")
            unload_models(models)

        # Both scoring passes are slow (one judge call per row) and now run by default, so a
        # failure or Ctrl+C partway through must never throw away the whole finished run --
        # rows scored so far keep their scores, the rest stay blank, and the run is saved either
        # way. scripts/backfill_quality_scores.py is idempotent and finishes whatever is blank.
        for scoring_pass in ([lambda: score_quality_pass_local(rows, score_quality_local)] if score_quality_local else []) + \
                            ([lambda: score_quality_pass(rows), lambda: score_draft_pass(rows)] if score_quality else []):
            try:
                scoring_pass()
            except (Exception, KeyboardInterrupt) as e:
                print(f"\n  WARNING: quality scoring stopped early ({type(e).__name__}: {e}).")
                print("  The run itself is being saved anyway. To fill in whatever is still blank, run both:")
                print("      python scripts/backfill_quality_scores.py")
                print("      python scripts/backfill_quality_scores.py --draft")
                break

        df = pd.DataFrame(rows)
        df.to_csv(log_path, index=False)
        for unit, group in df.groupby("business_unit"):
            group.to_csv(f"{LOGS_DIR}/results_log_{unit}.csv", index=False)

        existing_history = lock.read()
        history = pd.concat([existing_history, df], ignore_index=True) if not existing_history.empty else df
        lock.write(history)
        print(f"\nRun {run_id} appended to {HISTORY_PATH} ({history['run_id'].nunique()} run(s) in history)")
    print(f"Released lock on {HISTORY_PATH}.")

    print(f"\nSaved {len(df)} results to {log_path} (plus one log per business unit)")
    print("\nDecisions by scenario type:")
    print(df.groupby("is_exception")["decision"].value_counts().unstack(fill_value=0).to_string())
    print("\nMedian total latency (ms) by decision:")
    print(df.groupby("decision")["total_latency_ms"].median().round(0).to_string())
    if router is not None:
        went_up = df["decision"] != "LOCAL"      # the router said escalate: either the cache or Claude answered
        print(f"\nRouter {router.version}: escalated {went_up.mean():.0%} of questions "
              f"({', '.join(f'{u} {went_up[df.business_unit == u].mean():.0%}' for u in sorted(df.business_unit.unique()))}); "
              f"average predicted quality {df['router_predicted_quality'].mean():.2f} against a cut-point of {router.cutoff:.2f}.")
    return df


def parse_cli_args(args: list) -> tuple:
    """Simple positional-or-flag parsing, kept deliberately lightweight rather than pulling
    in argparse for a few options. Returns (n, score_quality, local_judge_model, use_semantic_cache,
    use_learned_router).

    The learned router, the semantic cache and Claude quality evaluation are all ON by default;
    each has an explicit opt-out flag:
        python -m src.pipeline 100                  # cache ON, quality evaluation ON
        python -m src.pipeline 100 --nocache        # skip the semantic cache
        python -m src.pipeline 100 --noquality      # skip the post-run Claude quality evaluation
        python -m src.pipeline 100 --nocache --noquality
        python -m src.pipeline 100 --threshold-router   # route with the old confidence pass mark instead
        python -m src.pipeline 100 --score-quality-local llama3.2:3b   # extra, opt-in local judge
    """
    flags = {"--nocache", "--noquality", "--threshold-router", "--score-quality-local", "--no-redact"}
    unknown = [a for a in args if a.startswith("--") and a not in flags]
    if unknown:
        raise SystemExit(f"Unknown option(s): {' '.join(unknown)}. "
                         f"Valid options: --nocache, --noquality, --threshold-router, --no-redact, --score-quality-local <model>")
    local_judge_model = None
    if "--score-quality-local" in args:
        idx = args.index("--score-quality-local")
        if idx + 1 >= len(args):
            raise SystemExit("--score-quality-local needs a model name, e.g. --score-quality-local llama3.2:3b")
        local_judge_model = args[idx + 1]
    positional = [a for a in args if a not in flags and a != local_judge_model]
    n = int(positional[0]) if positional else N_SAMPLES
    return n, "--noquality" not in args, local_judge_model, "--nocache" not in args, "--threshold-router" not in args


def main(argv=None) -> None:
    """Command-line entry point: parse the options, say which router, cache and quality scoring are on,
    and run the pipeline on a random sample of the synthetic questions.
    """
    raw_args = sys.argv[1:] if argv is None else argv
    n, score_quality, local_judge_model, use_semantic_cache, use_learned_router = parse_cli_args(raw_args)
    global REDACT_PII
    REDACT_PII = "--no-redact" not in raw_args
    if REDACT_PII:
        print(f"Personal-data filter: ON (default, {FILTER_VERSION}). Identifiers are replaced with placeholders before text goes to "
              f"Claude, the cache lookup, the examiner or the log. It catches patterned identifiers only, not free-text names or "
              f"addresses (see src/privacy.py). Pass --no-redact only to reproduce older runs.")
    else:
        print("Personal-data filter: OFF (--no-redact). Raw question text goes to Claude, the examiner and the log.")
    if use_learned_router:
        print("Router: LEARNED (default). After Tier 1 answers, a trained model predicts how good the answer is and "
              "escalates it if the prediction is below its cut-point. Pass --threshold-router for the old confidence rule.")
    else:
        print("Router: THRESHOLD rule (--threshold-router), the older confidence pass mark for each business unit.")
    if use_semantic_cache:
        print("Semantic cache: ON (default). An escalation first checks for a close-enough past Claude answer "
              "before calling Claude again. Pass --nocache to turn it off.")
    else:
        print("Semantic cache: OFF (--nocache). Every escalation will call Claude.")
    if score_quality:
        print(f"Quality evaluation: ON (default). After processing, every one of the {n} rows' final answers -- whether "
              f"answered by Tier 1, served from the cache, or answered by Tier 2 -- gets one Claude judge call, and every "
              f"escalated row's discarded Tier 1 draft gets one more (local rows just copy their final-answer scores), "
              f"so no quality cell is left blank. Pass --noquality to skip.")
    else:
        print("Quality evaluation: OFF (--noquality). Rows are saved with blank quality columns; "
              "run scripts/backfill_quality_scores.py to fill them in later.")
    if local_judge_model:
        print(f"Local quality first-pass is ON via {local_judge_model}: cheap/free, but not the numbers to report -- see section 13 of the user manual.")
    run_pipeline(load_random_sample(n), score_quality=score_quality, score_quality_local=local_judge_model,
                 use_semantic_cache=use_semantic_cache, use_learned_router=use_learned_router)


if __name__ == "__main__":
    main()
